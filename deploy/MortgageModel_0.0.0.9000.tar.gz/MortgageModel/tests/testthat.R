library(testthat)
library(MortgageModel)

test_check("MortgageModel")
